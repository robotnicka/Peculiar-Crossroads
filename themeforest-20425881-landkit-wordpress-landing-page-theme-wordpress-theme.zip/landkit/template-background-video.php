<?php
// =============================================================================
// TEMPLATE NAME: Background video
// -----------------------------------------------------------------------------
// Background video template.
// Documentation: framework-y.com/templates/base/template-background-video.html
// =============================================================================

if (defined("HC_PLUGIN_PATH")) {
    include(HC_PLUGIN_PATH . "/global-content.php");
}
get_header();
landkit_the_content();
get_footer();
?>
</div>

<?php
get_footer();
?>
